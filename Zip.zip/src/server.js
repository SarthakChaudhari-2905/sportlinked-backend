import app from "./app.js";
import env from "./config/env.js";
import {
  connectDatabase,
  disconnectDatabase,
} from "./config/db.js";

const startServer = async () => {
  try {
    await connectDatabase();

    const server = app.listen(
      env.port,
      () => {
        console.log("");
        console.log("====================================");
        console.log("       SPORTLINKED BACKEND");
        console.log("====================================");
        console.log(
          `Environment : ${env.nodeEnv}`
        );
        console.log(
          `Server      : http://localhost:${env.port}`
        );
        console.log(
          `API         : http://localhost:${env.port}/api/v1`
        );
        console.log(
          `Health      : http://localhost:${env.port}/api/v1/health`
        );
        console.log("====================================");
        console.log("");
      }
    );

    // Graceful shutdown
    const shutdown = async (signal) => {
      console.log(
        `\n${signal} received. Shutting down...`
      );

      server.close(async () => {
        await disconnectDatabase();

        console.log("Server shut down successfully.");
        process.exit(0);
      });
    };

    process.on("SIGINT", () => shutdown("SIGINT"));
    process.on("SIGTERM", () => shutdown("SIGTERM"));
  } catch (error) {
    console.error(
      "Failed to start SportLinked server:",
      error.message
    );

    process.exit(1);
  }
};

startServer();