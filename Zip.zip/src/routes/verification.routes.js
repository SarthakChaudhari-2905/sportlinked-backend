import express from "express";

import authenticate from "../middleware/auth.middleware.js";

import {
  adminOnly,
} from "../middleware/role.middleware.js";

import validate from "../middleware/validate.middleware.js";

import {
  submitVerificationSchema,
  reviewVerificationSchema,
} from "../validators/verification.validator.js";

import {
  submit,
  getMine,
  getPending,
  review,
} from "../controllers/verification.controller.js";

const router =
  express.Router();

// ==========================================
// USER ROUTES
// ==========================================

router.post(
  "/",
  authenticate,
  validate(
    submitVerificationSchema
  ),
  submit
);

router.get(
  "/mine",
  authenticate,
  getMine
);

// ==========================================
// ADMIN ROUTES
// ==========================================

router.get(
  "/pending",
  authenticate,
  adminOnly,
  getPending
);

router.patch(
  "/:id/review",
  authenticate,
  adminOnly,
  validate(
    reviewVerificationSchema
  ),
  review
);

export default router;