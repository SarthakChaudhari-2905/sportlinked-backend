import express from "express";

import authenticate from "../middleware/auth.middleware.js";

import validate from "../middleware/validate.middleware.js";

import {
  createCertificateSchema,
  updateCertificateSchema,
} from "../validators/certificate.validator.js";

import {
  create,
  getMine,
  getPublic,
  update,
  remove,
} from "../controllers/certificate.controller.js";

const router = express.Router();

router.post(
  "/",
  authenticate,
  validate(createCertificateSchema),
  create
);

router.get(
  "/mine",
  authenticate,
  getMine
);

router.patch(
  "/:id",
  authenticate,
  validate(updateCertificateSchema),
  update
);

router.delete(
  "/:id",
  authenticate,
  remove
);

router.get(
  "/public/:userId",
  getPublic
);

export default router;