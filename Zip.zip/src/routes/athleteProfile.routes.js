import express from "express";

import authenticate from "../middleware/auth.middleware.js";

import validate from "../middleware/validate.middleware.js";

import {
  createAthleteProfileSchema,
  updateAthleteProfileSchema,
} from "../validators/athleteProfile.validator.js";

import {
  create,
  getMine,
  update,
  getPublic,
} from "../controllers/athleteProfile.controller.js";

const router =
  express.Router();

// ==========================================
// PROTECTED
// ==========================================

router.post(
  "/",
  authenticate,
  validate(
    createAthleteProfileSchema
  ),
  create
);

router.get(
  "/me",
  authenticate,
  getMine
);

router.patch(
  "/me",
  authenticate,
  validate(
    updateAthleteProfileSchema
  ),
  update
);

// ==========================================
// PUBLIC
// ==========================================

router.get(
  "/:userId",
  getPublic
);

export default router;