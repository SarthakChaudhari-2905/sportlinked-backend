import express from "express";

import authenticate from "../middleware/auth.middleware.js";

import validate from "../middleware/validate.middleware.js";

import {
  createOrganizationSchema,
  updateOrganizationSchema,
} from "../validators/organization.validator.js";

import {
  create,
  getById,
  getMine,
  update,
  addOrganizationMember,
} from "../controllers/organization.controller.js";

const router =
  express.Router();

router.post(
  "/",
  authenticate,
  validate(createOrganizationSchema),
  create
);

router.get(
  "/mine",
  authenticate,
  getMine
);

router.patch(
  "/:id",
  authenticate,
  validate(updateOrganizationSchema),
  update
);

router.post(
  "/:id/members",
  authenticate,
  addOrganizationMember
);

router.get(
  "/:id",
  getById
);

export default router;