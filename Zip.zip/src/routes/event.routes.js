import express from "express";

import authenticate from "../middleware/auth.middleware.js";

import validate from "../middleware/validate.middleware.js";

import {
  createEventSchema,
  updateEventSchema,
} from "../validators/event.validator.js";

import {
  create,
  publish,
  getById,
  getOrganizationEvents,
  update,
  remove,
} from "../controllers/event.controller.js";

const router =
  express.Router();

router.post(
  "/",
  authenticate,
  validate(createEventSchema),
  create
);

router.get(
  "/organization/:organizationId",
  authenticate,
  getOrganizationEvents
);

router.patch(
  "/:id",
  authenticate,
  validate(updateEventSchema),
  update
);

router.post(
  "/:id/publish",
  authenticate,
  publish
);

router.delete(
  "/:id",
  authenticate,
  remove
);

router.get(
  "/:id",
  getById
);

export default router;