import express from "express";

import {
  register,
  login,
  refresh,
  logout,
  getCurrentUser,
} from "../controllers/auth.controller.js";

import authenticate from "../middleware/auth.middleware.js";

import validate from "../middleware/validate.middleware.js";

import {
  registerSchema,
  loginSchema,
} from "../validators/auth.validator.js";

const router = express.Router();

// ==========================================
// PUBLIC AUTH ROUTES
// ==========================================

router.post(
  "/register",
  validate(registerSchema),
  register
);

router.post(
  "/login",
  validate(loginSchema),
  login
);

router.post(
  "/refresh",
  refresh
);

router.post(
  "/logout",
  logout
);

// ==========================================
// PROTECTED AUTH ROUTES
// ==========================================

router.get(
  "/me",
  authenticate,
  getCurrentUser
);

export default router;