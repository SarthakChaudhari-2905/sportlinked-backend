import express from "express";

import authenticate from "../middleware/auth.middleware.js";

import validate from "../middleware/validate.middleware.js";

import {
  createAchievementSchema,
  updateAchievementSchema,
} from "../validators/achievement.validator.js";

import {
  create,
  getMine,
  getPublic,
  update,
  remove,
} from "../controllers/achievement.controller.js";

const router = express.Router();

router.post(
  "/",
  authenticate,
  validate(createAchievementSchema),
  create
);

router.get(
  "/mine",
  authenticate,
  getMine
);

router.patch(
  "/:id",
  authenticate,
  validate(updateAchievementSchema),
  update
);

router.delete(
  "/:id",
  authenticate,
  remove
);

router.get(
  "/public/:userId",
  getPublic
);

export default router;