import express from "express";

import authenticate from "../middleware/auth.middleware.js";

import validate from "../middleware/validate.middleware.js";

import {
  createAthleteVideoSchema,
  updateAthleteVideoSchema,
} from "../validators/athleteVideo.validator.js";

import {
  create,
  getMine,
  getPublic,
  update,
  remove,
  view,
} from "../controllers/athleteVideo.controller.js";

const router = express.Router();

router.post(
  "/",
  authenticate,
  validate(createAthleteVideoSchema),
  create
);

router.get(
  "/mine",
  authenticate,
  getMine
);

router.patch(
  "/:id",
  authenticate,
  validate(updateAthleteVideoSchema),
  update
);

router.delete(
  "/:id",
  authenticate,
  remove
);

router.get(
  "/public/:userId",
  getPublic
);

router.post(
  "/:id/view",
  view
);

export default router;