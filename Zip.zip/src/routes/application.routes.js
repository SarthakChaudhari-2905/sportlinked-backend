import express from "express";

import authenticate from "../middleware/auth.middleware.js";
import validate from "../middleware/validate.middleware.js";

import {
  createApplicationSchema,
  updateApplicationStatusSchema,
} from "../validators/application.validator.js";

import {
  create,
  getMine,
  getById,
  getForEvent,
  updateStatus,
  withdraw,
} from "../controllers/application.controller.js";

const router = express.Router();

/*
 * Athlete submits application
 */
router.post(
  "/",
  authenticate,
  validate(createApplicationSchema),
  create
);

/*
 * Athlete's applications
 */
router.get(
  "/mine",
  authenticate,
  getMine
);

/*
 * Organization gets applications
 * for an event
 *
 * Optional:
 * ?status=SHORTLISTED
 */
router.get(
  "/event/:eventId",
  authenticate,
  getForEvent
);

/*
 * Get single application
 */
router.get(
  "/:id",
  authenticate,
  getById
);

/*
 * Organization updates status
 */
router.patch(
  "/:id/status",
  authenticate,
  validate(updateApplicationStatusSchema),
  updateStatus
);

/*
 * Athlete withdraws
 */
router.post(
  "/:id/withdraw",
  authenticate,
  withdraw
);

export default router;