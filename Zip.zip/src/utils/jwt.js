import jwt from "jsonwebtoken";
import env from "../config/env.js";

const generateAccessToken = (user) => {
  return jwt.sign(
    {
      sub: user._id.toString(),
      role: user.role,
      type: "access",
    },
    env.jwt.accessSecret,
    {
      expiresIn: env.jwt.accessExpiresIn,
    }
  );
};

const generateRefreshToken = (user) => {
  return jwt.sign(
    {
      sub: user._id.toString(),
      type: "refresh",
    },
    env.jwt.refreshSecret,
    {
      expiresIn: env.jwt.refreshExpiresIn,
    }
  );
};

const verifyAccessToken = (token) => {
  return jwt.verify(
    token,
    env.jwt.accessSecret
  );
};

const verifyRefreshToken = (token) => {
  return jwt.verify(
    token,
    env.jwt.refreshSecret
  );
};

export {
  generateAccessToken,
  generateRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
};